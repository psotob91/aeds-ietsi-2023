##¿QUÉ NOVEDADES VAS A AGREGAR AL MANUAL PRÓXIMAMENTE?
#Agregar una sección de "cómo actualizar tu R desde RStudio con installr"
#Agegar una version propia en video del tutorial
#